package AllPrograms;

public class methodoverloading {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("method 1");
		main("tushar", 2);
		main(2,3);
	}

	public static void main(String args, int a) {
		// TODO Auto-generated method stub
		System.out.println("method 2");
	}
	
	public static void main(int a,int b) {
		// TODO Auto-generated method stub
		System.out.println("method 3");
	}
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		System.out.println("method 1");
//	}
}
